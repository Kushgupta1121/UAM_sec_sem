clear all;
close all;
clc;

input_img1= imread('mountain1.jpg');
input_img2= imread('mountain2.jpg');
input_img3= imread('mountain3.jpg');
input_img4= imread('mountain4.jpg');


th = 0.05; %[0.01 0.05 0.1 0.5 1]
display=1;

%Calculating first Homography
H_6 = homography_auto_vmmc_2(input_img1, input_img2, th, display);

%Making First Transform
tfrom_6=maketform('projective',H_6');

%Resulted stichted Image using the tform_6
Result_img_6=stitch_vmmc(input_img2, input_img1, tfrom_6);
figure(3);
imshow(Result_img_6);

%Calculating second Homography
H_7 = homography_auto_vmmc_2(Result_img_6, input_img3, th, display);

%Making second Transform
tfrom_7=maketform('projective',H_7');

%Resulted stichted Image using the tform_6
Result_img_7=stitch_vmmc(input_img3, Result_img_6, tfrom_7);
figure(6);
imshow(Result_img_7);

