clear all;
close all;
clc;

input_img1= imread('mountain1.jpg');
input_img2= imread('mountain2.jpg');

th = 0.01; %[0.01 0.05 0.1 0.5 1]
display=1;
%imshow(input_img1);
%%imshow(input_img2);

H_6 = homography_auto_vmmc_2(input_img1, input_img2, th, display);

tfrom_6=maketform('projective',H_6');

%Resulted stichted Image using the tform_6
Result_img_6=stitch_vmmc(input_img2, input_img1, tfrom_6);
figure(3);
imshow(Result_img_6);