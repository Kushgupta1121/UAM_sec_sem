clc;
clear all;
close all;

%Reading the hopper_vanishing image
input_img3=imread('hopper_vanishing.bmp');
objective_img=imread('hopper_reference.bmp');

%Manually selecting the xy-origin co-ordinates for the Source Image
xy_origin1 = get_user_points_vmmc(input_img3);

%Manually selecting the xy-origin co-ordinates for the target Image
xy_target = get_user_points_vmmc(objective_img);

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
H_5=homography_solve_vmmc(xy_origin1,xy_target);

% Creating the transform
tfrom_5=maketform('projective',H_5');

% Resulted Image using the tform
Result_img_6=imtransform(input_img3,tfrom_5,'XData',[1 size(input_img3,2)],'YData',[1 size(input_img3,1)]);

%raising the figure
figure();
subplot 441;
imshow(input_img3);
title('Original Image');

%Plotting the Transformed Image
subplot 442;
imshow(Result_img_6);
title('Restored Image 6');

%Calculating the energy difference between the two Images
energy_difference_2=get_error_energy_vmmc(objective_img,Result_img_6);
fprintf('Energy_difference %d', energy_difference_2);

x=linspace(0,size(input_img3,2));

a1 = H_5(3,1)/H_5(3,3);
a2 = H_5(3,2)/H_5(3,3);
a3 = H_5(3,3)/H_5(3,3);

%line joining infinity points
y  = ((-(a1/a2)*x)-(a3/a2));

A =   [xy_origin1(1,1) xy_origin1(2,1)]; %[253 185];
B =  [xy_origin1(1,2) xy_origin1(2,2)]; %371 161]; 
C =  [xy_origin1(1,3) xy_origin1(2,3)];%[414 325]; 
D =  [xy_origin1(1,4) xy_origin1(2,4)]; %[206 270];

% 1st line
m1 = ((B(2)-A(2))/(B(1)-A(1)));%(B(2)-B(1))/(A(2)-A(1));
n1 = B(2) - B(1)*m1;
y1 = m1*x + n1;

% 2nd line
m2 = ((C(2)-B(2))/(C(1)-B(1)));
n2 = C(2) - C(1)*m2;
y2 = m2*x + n2;

% 3rd line
m3 = ((D(2)-C(2))/(D(1)-C(1)));
n3 = D(2) - D(1)*m3;
y3 = m3*x + n3;

% 4th line
m4 = ((D(2)-A(2))/(D(1)-A(1)));
n4 = D(2) - D(1)*m4;
y4 = m4*x + n4;

hold on
subplot 443;
imshow(input_img3);
line(x, y1,'Color','red')
line(x, y2,'Color','red')
line(x, y3,'Color','red')
line(x, y4,'Color','red')
line(x, y,'Color','blue')
title('Points at Infinity')
hold off
