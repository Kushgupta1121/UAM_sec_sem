clc;
clear;

%%=======Exercise--1=======
    %Reading the Image
Img=imread('Hopper.JPG');
figure(1);
title('Exercise-1');
subplot 421;
imshow(Img);
title('Original Image');

% given set of co-ordinates for origin and target
xy_origin = [41 484 586 72; 
            124 30 299 414];
xy_target = [32 632 632 32; 
            25 25 468 468];

%=======Method-1=======

%Defining the Projective Transform H matrix
tfrom=maketform('projective',transpose(xy_origin),transpose(xy_target));

%Transforming the Image using H.
Result_img=imtransform(Img,tfrom,'XData',[1 size(Img,2)],'YData',[1 size(Img,1)]);

subplot 422;
imshow(Result_img);
title('Restored Image- Method 1');

%=======Method-2=======
subplot 423;
imshow(Img);
title('Original Image');

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
H=homography_solve_vmmc(xy_origin,xy_target);

% Creating the transform
tfrom1=maketform('projective',H');

% Resulted Image using the tform1
Result_img2=imtransform(Img,tfrom1,'XData',[1 size(Img,2)],'YData',[1 size(Img,1)]);

% Plotting the resulted Image 2
subplot 424;
imshow(Result_img2);
title('Restored Image- Method 2');

% Calculating the energy difference between the two Result Images
energy_difference=get_error_energy_vmmc(Result_img,Result_img2);


