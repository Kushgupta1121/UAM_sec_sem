%%=======Exercise--2=======
%========Part-1========
%Reading the hopper image
Img=imread('Hopper.JPG');

%raising the figure
figure(2);
title('Exercise-2');

%Plotting the original Image
subplot 221;
imshow(Img);
title('Original Image');

%Refernce Black Image
ref_img=uint8(zeros(size(Img,1),size(Img,2)));
%42 124; 485 28; 
%72 419; 588 300;

%Selecting the user defined points for the Original Image
user_pts=get_user_points_vmmc(Img);

%Selecting the user defined points for the Refernce black Image
user_pts_black_img=get_user_points_vmmc(ref_img);

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
H_2=homography_solve_vmmc(user_pts,user_pts_black_img);

% Creating the transform
tfrom_2=maketform('projective',H_2');

% Resulted Image using the tform
Result_img_3=imtransform(Img,tfrom_2,'XData',[1 size(Img,2)],'YData',[1 size(Img,1)]);

%Plotting the Transformed Image
subplot 222;
imshow(Result_img_3);
title('Restored Image 3');


%%========Part-2========

%Reading the input Image
input_img2=imread('perspective_pattern.bmp');

figure(3);
subplot 221;
imshow(input_img2);
title('Original Image');

% Pre-defined co-ordinates.
xy_origin = [18 475 599 41; 59 11 420 446];
xy_target = [4 604 604 4; 4 4 466 466];

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
H_3=homography_solve_vmmc(xy_origin,xy_target);

% Creating the transform
tfrom_3=maketform('projective',H_3');

% Resulted Image using the tform
Result_img_4=imtransform(input_img2,tfrom_3,'XData',[1 size(input_img2,2)],'YData',[1 size(input_img2,1)]);

%Plotting the Transformed Image
subplot 222;
imshow(Result_img_4);
title('Restored Image 4');

% Reading the refernce_pattern Image
input_img3=imread('reference_pattern.bmp');
% Calculating the energy difference between the two Images
energy_difference_1=get_error_energy_vmmc(input_img3,Result_img_4);

%%========Part-3========
figure(4);
subplot 221;
imshow(input_img2);
title('Original Image');

%Manually selecting the xy-origin co-ordinates
xy_origin1 = get_user_points_vmmc(input_img2);

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
H_4=homography_solve_vmmc(xy_origin1,xy_target);

% Creating the transform
tfrom_4=maketform('projective',H_4');

% Resulted Image using the tform
Result_img_5=imtransform(input_img2,tfrom_4,'XData',[1 size(input_img2,2)],'YData',[1 size(input_img2,1)]);

%Plotting the Transformed Image
subplot 222;
imshow(Result_img_5);
title('Restored Image 5');

%Calculating the energy difference between the two Images
energy_difference_2=get_error_energy_vmmc(input_img2,Result_img_5);
