%%=======Exercise--3=======
%========Part-1========

%Reading the hopper image
input_img3=imread('perspective_pattern.bmp');
objective_img=imread('reference_pattern.bmp');

%Manually selecting the xy-origin co-ordinates for the Source Image
xy_origin1 = get_user_points_vmmc(input_img3);

%Manually selecting the xy-origin co-ordinates for the target Image
xy_target = get_user_points_vmmc(objective_img);

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
H_5=homography_solve_vmmc(xy_origin1,xy_target);

% Creating the transform
tfrom_5=maketform('projective',H_5');

% Resulted Image using the tform
Result_img_6=imtransform(input_img3,tfrom_5,'XData',[1 size(input_img3,2)],'YData',[1 size(input_img3,1)]);

%raising the figure
figure();
subplot 221;
imshow(input_img3);
title('Original Image');

%Plotting the Transformed Image
subplot 222;
imshow(Result_img_6);
title('Restored Image 6');

%Calculating the energy difference between the two Images
energy_difference_2=get_error_energy_vmmc(objective_img,Result_img_6);
fprintf('Energy_difference %d', energy_difference_2);


% 4 pts Energy_difference 9.699957e+03
% 8 pts Energy_difference 1.151060e+04
% 12 pts Energy_difference 1.224981e+04

%========Part-2========
%%Run only part 2
%Reading the hopper image
input_img4=imread('Hopper.JPG');
target_img=imread('hopper_reference.bmp');

%Manually selecting the xy-origin co-ordinates for the Source Image
%xy_origin1 = get_user_points_vmmc(input_img4);

%Manually selecting the xy-origin co-ordinates for the target Image
%xy_target = get_user_points_vmmc(target_img);

% Calculating the Homography Matrix using the homography_solve_vmmc
% function
%H_5=homography_solve_vmmc(xy_origin1,xy_target);

H_5=homography_auto_vmmc(input_img4,target_img);

% Creating the transform
tfrom_5=maketform('projective',H_5');

% Resulted Image using the tform
Result_img_6=imtransform(input_img4,tfrom_5,'XData',[1 size(input_img4,2)],'YData',[1 size(input_img4,1)]);

%raising the figure
figure();
subplot 221;
imshow(input_img4);
title('Original Image');

%Plotting the Transformed Image
subplot 222;
imshow(Result_img_6);
title('Restored Image 6');

%Calculating the energy difference between the two Images
energy_difference_2=get_error_energy_vmmc(target_img,Result_img_6);
fprintf('Energy_difference %d', energy_difference_2);

% for part2 6pts Energy_difference 3.281878e+02


%num_points=1021, number_of_inliers= 252, number_of_iterations=3121,Energy_difference 7.123131e+01
%num_points=1021, number_of_inliers= 222, number_of_iterations=5815,Energy_difference 3.593978e+01
%num_points=1021, number_of_inliers= 252, number_of_iterations=1239,Energy_difference 7.123131e+01
%num_points=1021, number_of_inliers= 262, number_of_iterations=2717,Energy_difference 4.409427e+01
%num_points=1021, number_of_inliers= 262, number_of_iterations=8345,Energy_difference 4.409427e+01



