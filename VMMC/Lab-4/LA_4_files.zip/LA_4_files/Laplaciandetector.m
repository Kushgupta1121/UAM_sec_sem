%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VIDEO FOR MULTIPLE AND MOVING CAMERAS (VMMC)
% IPCV @ UAM
% Marcos Escudero-Vi�olo (marcos.escudero@uam.es)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clear all
% clf
clc
%% parameters
% for the fixed sigmas scale-space
noctaves    =     4; % number of octaves-3
nscales     =     10; % number of scales-10
sigma0      =     1; % initial sigma-1
%% calculate sigmas:
k = 1;
sigmas = zeros(1,noctaves*nscales);
for o = 0:noctaves-1 
    sigmas(k:(k+nscales-1)) = sigma0.*pow2([0:(nscales-1)]/nscales + o);
    k = k+nscales;
end
%% for the points
npoints         = 200; % number of local maxima and minima to extract (total number of points = 2*npoints)
%% read some image and convert it to gray and double [0,1]
ima = im2double(imread('sample_image.jpeg')); %Callao.jpg
ima=imresize(ima,[512 512]);
if size(ima,3) > 1
ima = rgb2gray(ima);
end
%% create Gaussian Scale-space
SS              = doScaleSpaceGivenSigmas(ima,sigmas);
%% extract Laplacian operator
LoG             = extractLaplacianGivenSigmas(SS,sigmas);
%% extract feature points 
[M,MaxPos,m,MinPos]=MinimaMaxima3D(LoG,1,0,npoints,npoints);
Maxima.v = m;
Maxima.x = MinPos(:,2);
Maxima.y = MinPos(:,1);
Maxima.s = MinPos(:,3);
minima.v = M;
minima.x = MaxPos(:,2);
minima.y = MaxPos(:,1);
minima.s = MaxPos(:,3);
%% show Local minima and Maxima
figure(10)
clf
imshow(ima)
hold on
viscircles([Maxima.x,Maxima.y], (sigmas(Maxima.s).^2)./2,'Color','r');
viscircles([minima.x,minima.y], (sigmas(minima.s).^2)./2,'Color','b');
