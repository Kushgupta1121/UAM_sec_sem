 %% ADAPTED FROM OPENSURF: https://es.mathworks.com/matlabcentral/fileexchange/28300-opensurf-including-image-warp
 
%% define options
Options=struct('tresh',0.005,'octaves',5,'init_sample',2,'upright',true,'extended',false,'verbose',false);
%% Load image
ima=imread('Callao.jpg');
%% Get the Key Points
PoI=OpenSurfDetector(ima,Options);
%% show the Key Points
figure(3)
% clf
imshow(ima)
hold on
for i=1:length(PoI)
   ip=PoI(i);
   
   S = 2 * fix(2.5 * ip.scale);
   R = fix(S / 2);

   pt =  [(ip.x), (ip.y)];

   if(ip.laplacian >0), myPen =[0 0 1]; else myPen =[1 0 0]; end
   
   rectangle('Curvature', [1 1],'Position', [pt(1)-R, pt(2)-R, S, S],'EdgeColor',myPen);
   
end


