%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VIDEO FOR MULTIPLE AND MOVING CAMERAS (VMMC)
% IPCV @ UAM
% Marcos Escudero-Vi�olo (marcos.escudero@uam.es)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%% parameters
% for the fixed sigmas scale-space
noctaves    =     3; % number of octaves
nscales     =     10; % number of scales
sigma0      =     1; % initial sigma.
%% calculate sigmas:
k = 1;
sigmas = zeros(1,noctaves*nscales);
for o = 0:noctaves-1, sigmas(k:(k+nscales-1)) = sigma0.*pow2([0:(nscales-1)]/nscales + o);k = k+nscales;end
%% for the points
npoints         = 500; % number of local maxima/minima and saddle to extract 
%% read some image and convert to gray and double [0,1]
rgbima = im2double(imread('Callao.jpg')); %im2double(imresize(imread('flowers.jpg'),0.1));
if size(rgbima,3) > 1
ima = rgb2gray(rgbima);
end
%% create Gaussian Scale-space
SS              = doScaleSpaceGivenSigmas(ima,sigmas);
%% extract Laplacian operator
kdet             = extractkGivenSigmas(SS,sigmas);
%% extract feature points 
%[M,MaxPos,m,MinPos]   = MinimaMaxima3D(DoH,1,0,npoints,npoints);
[M,MaxPos,m,MinPos]   = MinimaMaxima3D(kdet,1,0,npoints,npoints);
Saddle.v = m;Saddle.x = MinPos(:,2);Saddle.y = MinPos(:,1);Saddle.s = MinPos(:,3);
PoI.v    = M;PoI.x    = MaxPos(:,2);PoI.y = MaxPos(:,1);PoI.s = MaxPos(:,3);
%% show Local minima/Maxima and Saddle
figure;
clf
imshow(ima)
hold on
viscircles([PoI.x,PoI.y], (sigmas(PoI.s).^2)./2,'Color','r');
%viscircles([Saddle.x,Saddle.y], (sigmas(Saddle.s).^2)./2,'Color','g');

% %% extract Laplacian operator
% DoH             = extractDeterminantOfHessianGivenSigmas(SS,sigmas);
% %% extract feature points 
% [M,MaxPos,m,MinPos]   = MinimaMaxima3D(DoH,1,0,npoints,npoints);
% Saddle.v = m;Saddle.x = MinPos(:,2);Saddle.y = MinPos(:,1);Saddle.s = MinPos(:,3);
% PoI.v    = M;PoI.x    = MaxPos(:,2);PoI.y = MaxPos(:,1);PoI.s = MaxPos(:,3);
% %% show Local minima/Maxima and Saddle
% figure;
% clf
% imshow(ima)
% hold on
% viscircles([PoI.x,PoI.y], (sigmas(PoI.s).^2)./2,'Color','r');
% viscircles([Saddle.x,Saddle.y], (sigmas(Saddle.s).^2)./2,'Color','g');
% 
% %% extract Laplacian operator
% LoG             = extractLaplacianGivenSigmas(SS,sigmas);
% %% extract feature points 
% [M,MaxPos,m,MinPos]=MinimaMaxima3D(LoG,1,0,npoints,npoints);
% Maxima.v = m;Maxima.x = MinPos(:,2);Maxima.y = MinPos(:,1);Maxima.s = MinPos(:,3);
% minima.v = M;minima.x = MaxPos(:,2);minima.y = MaxPos(:,1);minima.s = MaxPos(:,3);
% %% show Local minima and Maxima
% figure;
% % clf
% imshow(ima)
% hold on
% viscircles([Maxima.x,Maxima.y], (sigmas(Maxima.s).^2)./2,'Color','r');
% viscircles([minima.x,minima.y], (sigmas(minima.s).^2)./2,'Color','b');
