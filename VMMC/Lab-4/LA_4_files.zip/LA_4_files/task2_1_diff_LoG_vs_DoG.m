%%Firstly run the Laplacian detector and the DoG detector with the same set
%%of values.
total=0;
back=0;
for j=1:numel(SS)
  
    
    if(rem(j, nscales)~=1)
        
        k=j-back;
        total = total + sum(sum(abs(DoG(:, :, k)-LoG(:, :, j))));
    else
        back=back+1;
    end

end

error=total/numel(DoG); % error per point

