%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VIDEO FOR MULTIPLE AND MOVING CAMERAS (VMMC)
% IPCV @ UAM
% Marcos Escudero-Vi�olo (marcos.escudero@uam.es)
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clear all
% clf
clc
%% parameters
% for the fixed sigmas scale-space
noctaves    =     1; % number of octaves
nscales     =     50; % number of scales
sigma0      =     1; % initial sigma.
%% calculate sigmas:
k = 1;
sigmas = zeros(1,noctaves*nscales);
%% for the points
npoints         = 100; % number of local maxima/minima and saddle to extract 
%% read some image and convert to gray and double [0,1]
ima = im2double(imread('Callao.jpg'));
if size(ima,3) > 1
ima = rgb2gray(ima);
end
%%
%%Non-linear scale space
addpath('non-linear scale-space');
if(noctaves==1)
    for o=1:nscales, sigmas(o)=(sqrt(o.*k));end
else
    for o = 0:noctaves-1, sigmas(k:(k+nscales-1)) = sigma0.*pow2([0:(nscales-1)]/nscales + o);k = k+nscales;end
end
    
SS = doNonLinearScaleSpaceGivenSigmas(ima, sigmas, 0.7, 3);
%% extract Laplacian operator
DoH             = extractDeterminantOfHessianGivenSigmas(SS,sigmas);
%% extract feature points 
[M,MaxPos,m,MinPos]   = MinimaMaxima3D(DoH,1,0,npoints,npoints);
Saddle.v = m;Saddle.x = MinPos(:,2);Saddle.y = MinPos(:,1);Saddle.s = MinPos(:,3);
PoI.v    = M;PoI.x    = MaxPos(:,2);PoI.y = MaxPos(:,1);PoI.s = MaxPos(:,3);
%% show Local minima/Maxima and Saddle
figure(1)
clf
imshow(ima)
hold on
viscircles([PoI.x,PoI.y], (sigmas(PoI.s).^2)./2,'Color','r');
viscircles([Saddle.x,Saddle.y], (sigmas(Saddle.s).^2)./2,'Color','g');
